import app
import treatdataset
import trainhumanclassifiermodels
from threadedvideostreamer import ThreadedVideoStreamer
import cv2
import os

if __name__ == '__main__':

    path_videos = '/put/your/path/to/videos/'

    for file in os.listdir(path):

        if file.startswith('.') or os.path.isdir(os.path.join(path,file)):
            continue

        app.run(os.path.join(path_videos, file), res=(1280, 720), track_interval=3, display=True)
