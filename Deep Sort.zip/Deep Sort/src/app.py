from threadedvideostreamer import ThreadedVideoStreamer
from roidetector import RegionOfInterestDetector
from humanclassifier import HumanClassifier
from imgtracker import ImgTracker
from objtracker import ObjTracker
from visualizer import Visualizer, NoViewerVisualizer
from extractfeatures import FeatureExtractor
import os
import cv2
import numpy as np
import time


def get_video_infomation(path, fps, res, str):
   
    video_info = {
        "video_name": os.path.basename(path),
        "image_size": res,
        "fps": fps,
        "streamer": str
    }

    return video_info


def run(path, res, track_interval=5, display=True):

    video = ThreadedVideoStreamer(path, res)
    video_info = get_video_infomation(path, video.fps, video.res, video)

    obj_tracker = ObjTracker()
    feat_extractor = FeatureExtractor("../encoder/mars-small128.pb")

    video.start()
    time.sleep(1)

    def frame_callback(vis):

        detection_centroids = []
        detection_bboxes = []

        (frame, n_frame) = video.read()

        (detection_centroids, detection_bboxes) = detection(frame)

        features = feat_extractor.extract_features(frame, np.copy(detection_bboxes))
        obj_tracker.update(detection_bboxes, detection_centroids, features)

        if display:
            vis.set_image(frame)
            vis.draw_tracks(obj_tracker.get_confirmed_tracks())
            vis.draw_detections(detection_bboxes)

        print("Tiempo total " + str(n_frame) + ": " + str(time.time()-start_time))

    vis = Visualizer(video_info) if display else NoViewerVisualizer(video_info)
    vis.run(frame_callback)


def detection(frame):
    centroids = []
    bboxes, = []
    
    ## Your code for detection goes here

    return (centroids, bboxes)